import { View, Text } from 'react-native'
import React from 'react'

const app = () => {
  return (
    <View>
      <todolist/>
      <todoform/>
    </View>
  )
}

export default app